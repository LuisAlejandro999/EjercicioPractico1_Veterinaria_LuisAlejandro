PROYECTO: EjercicioPractico1_Veterinaria
Tecnologías: Java 21, Spring Boot, Spring Web, Spring Data JPA, Thymeleaf, MySQL, Bootstrap.
Puerto: 8086
Base de datos: veterinaria_citas
Usuario local MySQL: usuario_caso_practico_01_var
Contraseña inicial según el PDF: 123456

IMPORTANTE:
1. El script database/veterinaria_citas.sql contiene DROP DATABASE veterinaria_citas. Si ya tiene datos importantes, haga una copia antes de ejecutarlo.
2. Si MySQL no permite crear usuarios, ejecute el script con un usuario administrador de MySQL (por ejemplo root).
3. El proyecto usa spring.jpa.hibernate.ddl-auto=validate; las tablas deben existir antes de iniciar la aplicación.
4. Bootstrap, el video y la fuente usan CDN, por lo que esos elementos visuales requieren internet. El backend y la conexión MySQL son locales.
5. Este proyecto es una base de trabajo educativa. Ejecútelo, pruebe cada función y asegúrese de poder explicar las clases y relaciones al docente.
